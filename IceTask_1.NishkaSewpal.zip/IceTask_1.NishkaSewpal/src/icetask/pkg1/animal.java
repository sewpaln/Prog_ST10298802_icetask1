/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask.pkg1;

import java.util.Scanner;

/**
 *
 * @author nishka
 */
public class animal {
    
    class Animal {

        public int getIDtag() {
            return IDtag;
        }

        public void setIDtag(int IDtag) {
            this.IDtag = IDtag;
        }

        public String getSpecies() {
            return species;
        }

        public void setSpecies(String species) {
            this.species = species;
        }
    protected int IDtag;
    protected String species;

    public Animal() {// Default constructor
    }

    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter IDtag: ");
        IDtag = scanner.nextInt();
        System.out.print("Enter species: ");
        species = scanner.next();
    }

    public void output() {
        System.out.println("IDtag: " + IDtag);
        System.out.println("Species: " + species);
    }
    }
    
}
