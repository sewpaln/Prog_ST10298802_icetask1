/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask.pkg1;

import icetask.pkg1.animal.Animal;
import java.util.Scanner;

/**
 *
 * @author nishka
 */
public class IceTask1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    bird brd = new bird();
    
        System.out.println("Enter details for the bird:");
        brd.input();
        
        System.out.println("Bird details:");
        brd.output();

        System.out.println();

    reptile rept = new reptile();
    
        System.out.println("Enter details for the reptile:");
        rept.input();
        
        System.out.println("Reptile details:");
        rept.output();
    }

    
}

   
    

    

