/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetask.pkg1;

import java.util.Scanner;

/**
 *
 * @author nishka
 */
public class reptile extends animal {
    
   
    private static class Reptile {
        
    private double bloodTemp;

        public double getBloodTemp() {
            return bloodTemp;
        }

        public void setBloodTemp(double bloodTemp) {
            this.bloodTemp = bloodTemp;
        }

        public Reptile() {
            
        }
        
        public void input() {
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter blood temperature: "); //prompt user to enter a temp.
        bloodTemp = scanner.nextDouble();
        }
        
        public void output() {
        
        System.out.println("Blood Temperature: " + bloodTemp);// set the output
    }
   
}
     
}
